# Topology Zoo

A reference of 50 topological spaces with point-set properties, fundamental groups, homology, Euler characteristics, derivations, and an applications chapter. It is built from one Python data source into two outputs: a web page and a LaTeX book.

## Files

- `data1.py` … `data4.py`: the spaces, and `data.py` combines them into `SPACES`, `CATS`, `PN`. Each space has `id`, `n` (name), `sym`, `cat`, `d`, `p` (8 properties: compact, connected, path-connected, Hausdorff, manifold, orientable, simply connected, contractible; 1/0/"b"/None/string), `pi`, `H`, `chi`, `how`, `why`, `ps` (point-set derivations), `alg` (algebraic derivations).
- `apps.py`: `APPS` and `FIELDS` for the applications chapter. Each application has `id`, `field`, `title`, `spaces` (zoo ids), `inv`, `text`, `refs`, and an optional `fig`.
- `figs.py`: matplotlib line-art figures in black ink, written to `figs/<id>.svg` (for the site) and `figs/<id>.pdf` (for the book). Run `python3 figs.py` to make all of them or `python3 figs.py torus klein` to make some.
- `build_html.py`: writes `topology-zoo.html`, a page body with no doctype, in the published Artifact format. The SVGs are inlined, MathJax 3.2.2 comes from jsDelivr, and the font is Old Standard TT.
- `build_tex.py`: writes `zoo.tex`. Compile it with `latexmk -pdf zoo.tex` to get `zoo.pdf`.

## Conventions

- All text fields are LaTeX-compatible. Math goes in `$...$`. Avoid `&`, `%` and `#` in prose, because they break pdflatex.
- The site defers MathJax inside `<details>` (class `mj-defer`) and typesets it when a drop-down opens.
- The design is a 1960s textbook: black on white with no shading.

## Rebuild

```
python3 figs.py && python3 build_html.py && python3 build_tex.py && latexmk -pdf zoo.tex
```

The published page is the claude.ai artifact "Topological Space Zoo". To view the page locally, wrap `topology-zoo.html` in a full HTML document.

## Unverified items

- The Budney–Sethares entry in `apps.py` was written without access to the paper.
- The solenoid-and-metre remark is a modelling observation.
- References not confirmed by search should be checked.
